-- Create the database
CREATE DATABASE IF NOT EXISTS cybersecurity_club;
USE cybersecurity_club;

-- Create the events table
CREATE TABLE events (
    id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(100) NOT NULL,
    description TEXT NOT NULL,
    event_date DATE NOT NULL,
    location VARCHAR(100) NOT NULL
);

-- Create the registrations table
CREATE TABLE registrations (
    id INT AUTO_INCREMENT PRIMARY KEY,
    student_name VARCHAR(100) NOT NULL,
    student_id VARCHAR(20) NOT NULL,
    email VARCHAR(100) NOT NULL,
    event_id INT NOT NULL,
    FOREIGN KEY (event_id) REFERENCES events(id)
);

-- Sample Cybersecurity Club Events
INSERT INTO events (title, description, event_date, location) VALUES
(
'Cybersecurity Awareness Workshop',
'Learn the fundamentals of cybersecurity, online safety, and digital threats through practical activities.',
'2026-09-12',
'Computer Lab 2'
),

(
'Capture The Flag (CTF) Competition',
'Participate in a hands-on cybersecurity competition and solve real-world security challenges.',
'2026-09-22',
'Innovation Center'
),

(
'Ethical Hacking Seminar',
'Discover ethical hacking techniques, penetration testing, and cybersecurity career opportunities.',
'2026-10-08',
'Main Auditorium'
),

(
'Network Security Training',
'Practice securing computer networks and defending systems against cyber attacks.',
'2026-10-20',
'Cybersecurity Lab'
);