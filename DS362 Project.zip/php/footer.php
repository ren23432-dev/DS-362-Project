<!-- Close the main content area that was opened in header.php -->
</main>

<footer>
    <div class="container">
        <p>&copy; 2026 Cybersecurity Club | Student Activities Department</p>
        <p>Designed by the Cybersecurity Club Team</p>
    </div>
</footer>

</body>
</html>