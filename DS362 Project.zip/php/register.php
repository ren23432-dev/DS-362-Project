<?php
require_once "db.php";
require_once "header.php";

$msg = "";
$msg_class = "";

// Check if the registration form was submitted
if (isset($_POST['action']) && $_POST['action'] == 'register') {

    $name = trim($_POST['student_name']);
    $student_id = trim($_POST['student_id']);
    $email = trim($_POST['email']);
    $event_id = intval($_POST['event_id']);

    // Server-side validation
    if (empty($name) || empty($student_id) || empty($email) || empty($event_id)) {
        $msg = "Please complete all required fields.";
        $msg_class = "error-msg";
    }
    elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $msg = "Please enter a valid email address.";
        $msg_class = "error-msg";
    }
    else {

        $name = mysqli_real_escape_string($cn, $name);
        $student_id = mysqli_real_escape_string($cn, $student_id);
        $email = mysqli_real_escape_string($cn, $email);

        $q = "INSERT INTO registrations (student_name, student_id, email, event_id)
              VALUES ('$name', '$student_id', '$email', $event_id)";

        if (mysqli_query($cn, $q)) {
            $msg = "You have successfully registered for the Cybersecurity Club event!";
            $msg_class = "success-msg";
        } else {
            $msg = "Unable to complete your registration. Please try again.";
            $msg_class = "error-msg";
        }
    }
}

// Automatically select the event if the user came from the event details page
$preselect = 0;

if (isset($_GET['preselect'])) {
    $preselect = intval($_GET['preselect']);
}

// Get all events
$events_rs = mysqli_query($cn, "SELECT id, title FROM events ORDER BY event_date ASC");
?>

<section class="panel">

    <h2>Cybersecurity Event Registration</h2>

    <?php if($msg != ""): ?>
        <div class="<?php echo $msg_class; ?>">
            <?php echo $msg; ?>
        </div>
    <?php endif; ?>

    <form action="register.php" method="post" onsubmit="return validateRegistration(this)">

        <input type="hidden" name="action" value="register">

        <div class="form-group">
            <label for="student_name">Full Name</label>
            <input
                type="text"
                id="student_name"
                name="student_name"
                placeholder="Enter your full name">
        </div>

        <div class="form-group">
            <label for="student_id">Student ID</label>
            <input
                type="text"
                id="student_id"
                name="student_id"
                placeholder="Enter your student ID">
        </div>

        <div class="form-group">
            <label for="email">University Email</label>
            <input
                type="email"
                id="email"
                name="email"
                placeholder="student@university.edu">
        </div>

        <div class="form-group">
            <label for="event_id">Select a Cybersecurity Event</label>

            <select id="event_id" name="event_id">

                <option value="">-- Select an Event --</option>

                <?php while($e = mysqli_fetch_assoc($events_rs)): ?>

                    <option
                        value="<?php echo $e['id']; ?>"
                        <?php if($preselect == $e['id']) echo "selected"; ?>>

                        <?php echo htmlspecialchars($e['title']); ?>

                    </option>

                <?php endwhile; ?>

            </select>

        </div>

        <button type="submit">Register Now</button>

    </form>

</section>

<?php require_once "footer.php"; ?>