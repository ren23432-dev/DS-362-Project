// check the registration form 
function validateRegistration(form) {
    var errors = "";
    
    // Check if any of the fields are left empty
    if (form.student_name.value.trim() === "") { errors += "Name is required.\n"; }
    if (form.student_id.value.trim() === "") { errors += "Student ID is required.\n"; }
    if (form.email.value.trim() === "") { errors += "Email is required.\n"; }
    
    // Check if the user selected an event from the dropdown
    if (form.event_id.value === "") { errors += "Please select an event.\n"; }
    
    // show a popup and stop the form from submitting
    if (errors !== "") { 
        alert("Please fix the following errors:\n" + errors); 
        return false; // Stops form submission
    }
    return true; // Allows form submission
}

// check the contact form
function validateContact(form) {
    var errors = "";
    
    // Check if name or message is empty
    if (form.name.value.trim() === "") { errors += "Name is required.\n"; }
    if (form.message.value.trim() === "") { errors += "Message is required.\n"; }
    
    if (errors !== "") { 
        alert(errors); 
        return false; 
    }
    return true;
}